package model;

import java.util.Scanner;

public class CardAcceptor implements MoneyAcceptor {
    private int amount = 0;
    private Scanner scanner = new Scanner(System.in);
    private boolean cardInserted = false;

    @Override
    public int getAmount() {
        if (!cardInserted) {
            System.out.println("Сначала вставьте карту");
            return 0;
        }
        return amount;
    }

    @Override
    public void addMoney(int amount) {
        if (!cardInserted) {
            insertCard();
        }

        if (cardInserted) {
            System.out.print("Введите одноразовый пароль из SMS: ");
            String password = scanner.nextLine();

            if (validatePayment(password)) {
                this.amount += amount;
                System.out.println("Баланс пополнен на " + amount + " руб.");
            } else {
                System.out.println("Ошибка оплаты");
            }
        }
    }

    @Override
    public boolean canBuy(int price) {
        return cardInserted && amount >= price;
    }

    @Override
    public void charge(int amount) {
        this.amount -= amount;
    }

    @Override
    public String getCurrencyName() {
        return "Банковская карта";
    }

    private void insertCard() {
        System.out.print("Введите номер карты: ");
        String cardNumber = scanner.nextLine();

        if (cardNumber.length() == 16) {
            System.out.print("Введите срок действия (ММ/ГГ): ");
            String expiry = scanner.nextLine();

            if (expiry.matches("\\d{2}/\\d{2}")) {
                cardInserted = true;
                System.out.println("Карта принята!");
            }
        }
    }

    private boolean validatePayment(String password) {
        return password.length() == 6;
    }

    public void ejectCard() {
        cardInserted = false;
        System.out.println("Карта извлечена");
    }
}