package model;

import enums.ActionLetter;

public class CocaCola extends Product {
    public CocaCola(ActionLetter actionLetter, int price) {
        super("Coca Cola", actionLetter, price);
    }
}
