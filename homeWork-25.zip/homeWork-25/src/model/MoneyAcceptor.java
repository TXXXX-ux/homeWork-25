package model;

public interface MoneyAcceptor {
    int getAmount();
    void addMoney(int amount);
    boolean canBuy(int price);
    void charge(int amount);
    String getCurrencyName();
}