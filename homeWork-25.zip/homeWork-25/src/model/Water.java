package model;

import enums.ActionLetter;

public class Water extends Product {
    public Water(ActionLetter actionLetter, int price) {
        super("Water", actionLetter, price);
    }
}
