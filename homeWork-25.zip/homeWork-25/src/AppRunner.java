import enums.ActionLetter;
import model.*;
import util.UniversalArray;
import util.UniversalArrayImpl;

import java.util.Scanner;

public class AppRunner {

    private final UniversalArray<Product> products = new UniversalArrayImpl<>();
    private MoneyAcceptor moneyAcceptor;

    private static boolean isExit = false;

    private AppRunner() {
        products.addAll(new Product[]{
                new Water(ActionLetter.B, 20),
                new CocaCola(ActionLetter.C, 50),
                new Soda(ActionLetter.D, 30),
                new Snickers(ActionLetter.E, 80),
                new Mars(ActionLetter.F, 80),
                new Pistachios(ActionLetter.G, 130)
        });
    }
    public static void run() {
        AppRunner app = new AppRunner();
        app.initPaymentMethod();
        while (!isExit) {
            app.startSimulation();
        }
    }

    private void initPaymentMethod() {
        System.out.println("Выберите способ оплаты:");
        System.out.println("1 - Монеты");
        System.out.println("2 - Банковская карта");

        Scanner scanner = new Scanner(System.in);
        String choice = scanner.nextLine();

        if ("1".equals(choice)) {
            moneyAcceptor = new CoinAcceptor(100);
        } else if ("2".equals(choice)) {
            moneyAcceptor = new CardAcceptor();
        }
    }

    private void startSimulation() {
        print("В автомате доступны:");
        showProducts(products);

        print("Способ оплаты: " + moneyAcceptor.getCurrencyName());
        print("Доступно средств: " + moneyAcceptor.getAmount());

        UniversalArray<Product> allowProducts = new UniversalArrayImpl<>();
        allowProducts.addAll(getAllowedProducts().toArray());
        chooseAction(allowProducts);
    }

    private UniversalArray<Product> getAllowedProducts() {
        UniversalArray<Product> allowProducts = new UniversalArrayImpl<>();
        for (int i = 0; i < products.size(); i++) {
            if (moneyAcceptor.canBuy(products.get(i).getPrice())) {
                allowProducts.add(products.get(i));
            }
        }
        return allowProducts;
    }

    private void chooseAction(UniversalArray<Product> products) {
        print(" a - Пополнить баланс");
        showActions(products);
        print(" h - Выйти");

        if (moneyAcceptor instanceof CardAcceptor) {
            print(" e - Извлечь карту");
        }

        String action = fromConsole().substring(0, 1);
        if ("a".equalsIgnoreCase(action)) {
            if (moneyAcceptor instanceof CoinAcceptor) {
                moneyAcceptor.addMoney(10);
                print("Вы пополнили баланс на 10");
            } else {
                print("Введите сумму для пополнения: ");
                try {
                    int amount = Integer.parseInt(fromConsole());
                    moneyAcceptor.addMoney(amount);
                } catch (NumberFormatException e) {
                    print("Неверная сумма!");
                }
            }
            return;
        }

        if ("e".equalsIgnoreCase(action) && moneyAcceptor instanceof CardAcceptor cardAcceptor) {
            cardAcceptor.ejectCard();
            return;
        }

        try {
            for (int i = 0; i < products.size(); i++) {
                if (products.get(i).getActionLetter().equals(ActionLetter.valueOf(action.toUpperCase()))) {
                    int price = products.get(i).getPrice();
                    if (moneyAcceptor.canBuy(price)) {
                        moneyAcceptor.charge(price);
                        print("Вы купили " + products.get(i).getName());
                    } else {
                        print("Недостаточно средств!");
                    }
                    break;
                }
            }
        } catch (IllegalArgumentException e) {
            if ("h".equalsIgnoreCase(action)) {
                isExit = true;
            } else {
                print("Недопустимая буква. Попробуйте еще раз.");
            }
        }
    }

    private void showActions(UniversalArray<Product> products) {
        for (int i = 0; i < products.size(); i++) {
            print(String.format(" %s - %s", products.get(i).getActionLetter().getValue(), products.get(i).getName()));
        }
    }

    private String fromConsole() {
        return new Scanner(System.in).nextLine();
    }

    private void showProducts(UniversalArray<Product> products) {
        for (int i = 0; i < products.size(); i++) {
            print(products.get(i).toString());
        }
    }

    private void print(String msg) {
        System.out.println(msg);
    }
}